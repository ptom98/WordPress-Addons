<?php
	/*
	Plugin Name: Simple Social Popup
	Plugin URI: http://convoymedia.com
	Description: Adds a simple popup containing social sharing icons
	Version: 1.0
	Author: Convoy Media
	Author URI: http://convoymedia.com
	*/

    add_action('wp_enqueue_scripts', 'convoymedia_ssp_scripts');
    function convoymedia_ssp_scripts() {
        wp_register_style( 'ssp', plugins_url('/simple-popup/jquery.simple-popup.min.css', __FILE__) );
		wp_enqueue_style( 'ssp' );
		wp_register_style( 'sspmain', plugins_url('/css/main.css', __FILE__) );
        wp_enqueue_style( 'sspmain' );
		wp_enqueue_script( 'sspscript', plugins_url('/simple-popup/jquery.simple-popup.min.js', __FILE__), array( 'jquery' ) );
		wp_enqueue_script( 'sspjs', plugins_url('/js/main.js', __FILE__), array( 'jquery' ) );
        wp_enqueue_script( 'fontawesome', 'https://use.fontawesome.com/03739d31ba.js', __FILE__);
    }

	// Add Shortcode
	function convoymedia_ssp($atts) {
		$return = "";
		
		$atts = shortcode_atts(
			array(
                'url' => get_the_permalink(), // form id
                'text' => get_the_title(), //shared text
				'color' => '#313131',
				'size' => '25'
            ), 
            $atts, 
			'ssp' 
        );
        
        $url = urlencode($atts['url']);
        $text = urlencode($atts['text']);

        $return = '<a href="#" data-url="' . $url . '" data-text="' . $text .'" class="ssp-share sharing-icon"><svg role="presentation" width="' . $atts['size'] . '" height="' . $atts['size'] . '" viewBox="0 0 50 50"><path style="fill:' . $atts['color'] . '" d="M39.8,35.4c-1.9,0-3.5,0.7-4.8,1.9L17.4,26.9c0.1-0.6,0.2-1.2,0.2-1.8c0-0.6-0.1-1.2-0.2-1.8l17.4-10.3c1.3,1.2,3.1,2,5,2c4.1,0,7.4-3.3,7.4-7.5c0-4.2-3.3-7.5-7.4-7.5c-4.1,0-7.4,3.4-7.4,7.5c0,0.6,0.1,1.2,0.2,1.8L15.2,19.7c-1.3-1.3-3.1-2-5-2c-4.1,0-7.4,3.4-7.4,7.5c0,4.2,3.3,7.5,7.4,7.5c1.9,0,3.7-0.8,5-2L32.8,41c-0.1,0.5-0.2,1.1-0.2,1.6c0,4,3.2,7.3,7.2,7.3c4,0,7.2-3.3,7.2-7.3C47,38.6,43.7,35.4,39.8,35.4z"></path></svg></a>';
		
		return $return;
	}
	add_shortcode( 'social', 'convoymedia_ssp' );

	function convoymedia_ssp_footer() {
		echo '<symbol id="svg--share" viewBox="0 0 50 50">
    			
  				</symbol>
				<div id="sharing-popup" style="display:none">
				<p><svg role="presentation" width="25" height="25" viewBox="0 0 50 50"><path style="fill:#313131" d="M39.8,35.4c-1.9,0-3.5,0.7-4.8,1.9L17.4,26.9c0.1-0.6,0.2-1.2,0.2-1.8c0-0.6-0.1-1.2-0.2-1.8l17.4-10.3c1.3,1.2,3.1,2,5,2c4.1,0,7.4-3.3,7.4-7.5c0-4.2-3.3-7.5-7.4-7.5c-4.1,0-7.4,3.4-7.4,7.5c0,0.6,0.1,1.2,0.2,1.8L15.2,19.7c-1.3-1.3-3.1-2-5-2c-4.1,0-7.4,3.4-7.4,7.5c0,4.2,3.3,7.5,7.4,7.5c1.9,0,3.7-0.8,5-2L32.8,41c-0.1,0.5-0.2,1.1-0.2,1.6c0,4,3.2,7.3,7.2,7.3c4,0,7.2-3.3,7.2-7.3C47,38.6,43.7,35.4,39.8,35.4z"></path></svg></p>
				<h3>Share with others online…</h3>
				<p>
					<a href="#" data-link="https://twitter.com/intent/tweet?url=[url]&text=[text]" class="share share-twitter">
						<i class="fa fa-twitter" aria-hidden="true"></i>
					</a>
					<a href="#" data-link="https://www.facebook.com/sharer.php?u=[url]" class="share share-facebook">
						<i class="fa fa-facebook" aria-hidden="true"></i>
					</a>
					<a href="#" data-link="https://www.linkedin.com/shareArticle?url=[url]&title=[text]" class="share share-linkedin">
						<i class="fa fa-linkedin" aria-hidden="true"></i>
					</a>
					<a href="#" data-link="https://plus.google.com/share?url=[url]" class="share share-google">
						<i class="fa fa-google-plus" aria-hidden="true"></i>
					</a>
					<a href="#" data-link="https://pinterest.com/pin/create/button?url=[url]]&media=data[url]&description=[text]" class="share share-pinterest">
						<i class="fa fa-pinterest-p" aria-hidden="true"></i>
					</a>

				</p>
			</div>';
	}
	add_action( 'wp_footer', 'convoymedia_ssp_footer' );
?>