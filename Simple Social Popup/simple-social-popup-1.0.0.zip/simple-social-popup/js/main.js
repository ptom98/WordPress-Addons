jQuery(document).ready(function($){
    $("a.ssp-share").on("click", function(e) {
        e.preventDefault();

        var temp_url = $(this).attr("data-url");
        var temp_text = $(this).attr("data-text");

        $(".share-facebook").attr("href", $(".share-facebook").attr("data-link").replace("[url]", temp_url).replace("[text]", temp_text));
        $(".share-twitter").attr("href", $(".share-twitter").attr("data-link").replace("[url]", temp_url).replace("[text]", temp_text));
        $(".share-linkedin").attr("href", $(".share-linkedin").attr("data-link").replace("[url]", temp_url).replace("[text]", temp_text));
        $(".share-google").attr("href", $(".share-google").attr("data-link").replace("[url]", temp_url).replace("[text]", temp_text));
        $(".share-pinterest").attr("href", $(".share-pinterest").attr("data-link").replace("[url]", temp_url).replace("[text]", temp_text));

        $(this).simplePopup({ type: "html", htmlSelector: "#sharing-popup" });
    });

    $("body").on("click", ".share", function(e) {
        e.preventDefault();
        PopupCenter($(this).attr('href'),"Share",'600','300');  
    })

    function PopupCenter(url, title, w, h) {
        // Fixes dual-screen position                         Most browsers      Firefox
        var dualScreenLeft = window.screenLeft != undefined ? window.screenLeft : window.screenX;
        var dualScreenTop = window.screenTop != undefined ? window.screenTop : window.screenY;
    
        var width = window.innerWidth ? window.innerWidth : document.documentElement.clientWidth ? document.documentElement.clientWidth : screen.width;
        var height = window.innerHeight ? window.innerHeight : document.documentElement.clientHeight ? document.documentElement.clientHeight : screen.height;
    
        var systemZoom = width / window.screen.availWidth;
        var left = (width - w) / 2 / systemZoom + dualScreenLeft
        var top = (height - h) / 2 / systemZoom + dualScreenTop
        var newWindow = window.open(url, title, 'scrollbars=yes, width=' + w / systemZoom + ', height=' + h / systemZoom + ', top=' + top + ', left=' + left);
    
        // Puts focus on the newWindow
        if (window.focus) newWindow.focus();
    }
});