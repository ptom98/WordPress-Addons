<?php
	/*
	Plugin Name: TiBi Video
	Plugin URI: http://convoymedia.com
	Description: Create a video with a users name using the TiBi API
	Version: 1.0
	Author: Convoy Media
	Author URI: http://convoymedia.com
	*/

    add_action('wp_enqueue_scripts', 'convoymedia_tibi_scripts');
    function callback_for_setting_up_scripts() {
        wp_register_style( 'evp', plugins_url('/content/global.css', __FILE__) );
        wp_enqueue_style( 'evp' );
        wp_enqueue_script( 'evpscript', plugins_url('/java/FWDEVPlayer.js', __FILE__), array( 'jquery' ) );
    }

	// Add Shortcode
	function convoymedia_tibi($atts) {
		$return = "";
		
		$atts = shortcode_atts(
			array(
				'apikey' => '', // form id
            ), 
            $atts, 
			'tibi' 
		);
        
        if ($atts['apikey'] === "") {
            $return = "Please specify an API Key";
        }
        else {
            $return = '<div id="tibiPlayer" style="margin:auto;"></div>';
            $return .= '<script type="text/javascript">
                    FWDEVPUtils.onReady(function(){
                
                        FWDEVPlayer.videoStartBehaviour = "pause";
                        
                        new FWDEVPlayer({       
                            //main settings
                            useYoutube:"yes",
                            useVimeo:"no",
                            instanceName:"player1",
                            parentId:"myDiv",
                            mainFolderPath:"content",
                            skinPath:"minimal_skin_dark",
                            displayType:"responsive",
                            fillEntireVideoScreen:"no",
                            playsinline:"yes",
                            autoScale:"yes",
                            useVectorIcons:"no",
                            useResumeOnPlay:"no",
                            useHEXColorsForSkin:"no",
                            openDownloadLinkOnMobile:"no",
                            normalHEXButtonsColor:"#FF0000",
                            selectedHEXButtonsColor:"#FFFFFF",
                            startAtVideoSource:2,
                            videoSource:[
                                {source:"content/videos/fwd-480p.mp4", label:"small version"},
                                {source:"content/videos/fwd-720p.mp4", label:"hd720"},
                                {source:"content/videos/fwd-1080p.mp4", label:"hd1080"}
                            ],
                            posterPath:"content/posters/mp4-poster.jpg, content/posters/mp4-poster-mobile.jpg",
                            googleAnalyticsTrackingCode:"",
                            showErrorInfo:"yes",
                            fillEntireScreenWithPoster:"yes",
                            rightClickContextMenu:"developer",
                            disableDoubleClickFullscreen:"no",
                            addKeyboardSupport:"yes",
                            useChromeless:"no",
                            showPreloader:"yes",
                            preloaderColors:["#999999", "#FFFFFF"],
                            autoPlay:"no",
                            loop:"no",
                            scrubAtTimeAtFirstPlay:"00:00:00",
                            maxWidth:600,
                            maxHeight:380,
                            volume:.8,
                            greenScreenTolerance:200,
                            backgroundColor:"#000000",
                            posterBackgroundColor:"#0099FF",
                            //logo settings
                            showLogo:"yes",
                            hideLogoWithController:"yes",
                            logoPosition:"topRight",
                            logoLink:"http://www.webdesign-flash.ro",
                            logoMargins:5,
                            //controller settings
                            showController:"yes",
                            showControllerWhenVideoIsStopped:"yes",
                            showVolumeScrubber:"yes",
                            showVolumeButton:"yes",
                            showTime:"yes",
                            showRewindButton:"yes",
                            showQualityButton:"yes",
                            showSubtitleButton:"yes",
                            showShareButton:"yes",
                            showDownloadButton:"yes",
                            showFullScreenButton:"yes",
                            repeatBackground:"yes",
                            controllerHeight:41,
                            controllerHideDelay:3,
                            startSpaceBetweenButtons:7,
                            spaceBetweenButtons:9,
                            mainScrubberOffestTop:14,
                            scrubbersOffsetWidth:4,
                            timeOffsetLeftWidth:5,
                            timeOffsetRightWidth:3,
                            volumeScrubberWidth:80,
                            volumeScrubberOffsetRightWidth:0,
                            timeColor:"#777777",
                            youtubeQualityButtonNormalColor:"#777777",
                            youtubeQualityButtonSelectedColor:"#FFFFFF",
                            //redirect at video end
                            redirectURL:"",
                            redirectTarget:"_blank",
                            //cuepoints
                            executeCuepointsOnlyOnce:"no",
                            //annotations
                            annotiationsListId:"none",
                            showAnnotationsPositionTool:"no",
                            //subtitles
                            showSubtitleButton:"yes",
                            subtitlesOffLabel:"Subtitle off",
                            startAtSubtitle:1,
                            subtitlesSource:[
                                {subtitlePath:"content/english_subtitle.txt", subtileLabel:"English"},
                                {subtitlePath:"content/romanian_subtitle.txt", subtileLabel:"Romanian"},
                                {subtitlePath:"content/spanish_subtitle.txt", subtileLabel:"Spanish"}
                            ],
                            //lightbox settings
                            lightBoxBackgroundOpacity:.6,
                            lightBoxBackgroundColor:"#000000",
                            //sticky on scroll
                            stickyOnScroll:"no",
                            stickyOnScrollShowOpener:"yes",
                            stickyOnScrollWidth:"700",
                            stickyOnScrollHeight:"394",
                            //sticky display settings
                            showOpener:"yes",
                            showOpenerPlayPauseButton:"yes",
                            verticalPosition:"bottom",
                            horizontalPosition:"center",
                            showPlayerByDefault:"yes",
                            animatePlayer:"yes",
                            openerAlignment:"right",
                            mainBackgroundImagePath:"content/minimal_skin_dark/main-background.png",
                            openerEqulizerOffsetTop:-1,
                            openerEqulizerOffsetLeft:3,
                            offsetX:0,
                            offsetY:0,
                            //audio visualizer
                            audioVisualizerLinesColor:"#0099FF",
                            audioVisualizerCircleColor:"#FFFFFF",
                            //advertisement on pause window
                            aopwTitle:"Advertisement",
                            aopwSource:"",
                            aopwWidth:400,
                            aopwHeight:240,
                            aopwBorderSize:6,
                            aopwTitleColor:"#FFFFFF",
                            //playback rate / speed
                            showPlaybackRateButton:"yes",
                            defaultPlaybackRate:"1", //0.25, 0.5, 1, 1.25, 1.5, 2
                            //loggin
                            isLoggedIn:"no",
                            playVideoOnlyWhenLoggedIn:"yes",
                            loggedInMessage:"Please login to view this video.",
                            //embed window
                            embedWindowCloseButtonMargins:0,
                            borderColor:"#333333",
                            mainLabelsColor:"#FFFFFF",
                            secondaryLabelsColor:"#a1a1a1",
                            shareAndEmbedTextColor:"#5a5a5a",
                            inputBackgroundColor:"#000000",
                            inputColor:"#FFFFFF",
                            //a to b loop
                            useAToB:"yes",
                            atbTimeBackgroundColor:"transparent",
                            atbTimeTextColorNormal:"#FFFFFF",
                            atbTimeTextColorSelected:"#FF0000",
                            atbButtonTextNormalColor:"#888888",
                            atbButtonTextSelectedColor:"#FFFFFF",
                            atbButtonBackgroundNormalColor:"#FFFFFF",
                            atbButtonBackgroundSelectedColor:"#000000",
                        });             
                    });
                    
                    
                </script>';
        }
		
		return $return;
	}
	add_shortcode( 'tibi', 'convoymedia_tibi' );
?>